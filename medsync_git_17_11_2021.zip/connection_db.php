<?php
$link = mysqli_connect('localhost','c7253v76_teste','Teste!2021','c7253v76_medsync')
or die('Error connecting to the server: ' . mysqli_error($link));
?>