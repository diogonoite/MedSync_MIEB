<html>
<div class="sobre_nos">
<h1>A nossa equipa,</h1>
<div class="diogo">
    <img class="cara_diogo" src="./img/cara_diogo.png">
    <h2>Diogo Ramos</h2>
    <h3>Mestrado Integrado em Engenharia Biomédica - FCT/UNL</h3>
</div>
<div class="prof_claudia">
    <img class="cara_claudia" src="./img/prof_claudia.png">
    <h2>Prof. Cláudia Quaresma</h2>
    <h3>Departamento de Física - FCT/UNL</h3>
</div>
<div class="prof_micaela">
    <img class="cara_micaela" src="./img/prof_micaela.png">
    <h2>Prof. Micaela Fonseca</h2>
    <h3>Departamento de Física - FCT/UNL</h3>
</div>
</html>