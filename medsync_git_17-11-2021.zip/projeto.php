<html>
<link rel="stylesheet" type="text/css" href="./css/mainn.css">
<div class="informacao">
<h1>O que é a MedSync?</h1>
<img class="aleatorio" src="./img/sobre4.png">
</div>
</html>