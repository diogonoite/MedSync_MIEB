<html>
<div>
<p style="color:black; font-family:sans-serif; background-color:red; text-align:center;">Nome de utilizador já registado</p>
</div>
</hmtl>