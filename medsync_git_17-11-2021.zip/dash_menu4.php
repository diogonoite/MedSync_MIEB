<html>

<div class="navegar">
        <a href="dashboard.php?operacao=home"><i class="fa fa-home" aria-hidden="true"></i>Home</a>
        <a href="dashboard.php?operacao=utentes"><i class="fa fa-users" aria-hidden="true"></i>Utentes</a>
        <a href="dashboard.php?operacao=reabilitacao&sub=adicionarexercicio"><i class="fa fa-crosshairs" aria-hidden="true"></i>Reabilitação</a>
        <a href="logout.php" style="margin-top:15%;"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
</div>

</html>