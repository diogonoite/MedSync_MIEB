<html>
<link rel="stylesheet" type="text/css" href="./css/users.css">
<div class="navegar">
        <a href="dashboard_doente.php?operacao=home"><i class="fa fa-home" aria-hidden="true"></i>Home</a>
        <a href="dashboard_doente.php?operacao=reabilitacao_doente"><i class="fa fa-hospital-o" aria-hidden="true"></i>Reabilitação</a>
        <a href="dashboard_doente.php?operacao=feedback_doente"><i class="fa fa-comments-o" aria-hidden="true"></i>Feedback</a>
        <a href="dashboard_doente.php?operacao=perfil_doente"><i class="fa fa-user" aria-hidden="true"></i></i>Perfil</a>
        <a href="logout.php" style="margin-top:15%;"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
</div>

</html>