<html>

<div class="navegar">
        <a href="dashboard_admin.php?operacao=home"><i class="fa fa-home" aria-hidden="true"></i>Home</a>
        <a href="dashboard_admin.php?operacao=utentes"><i class="fa fa-users" aria-hidden="true"></i>Utentes</a>
        <a href="dashboard_admin.php?operacao=clinicos"><i class="fa fa-user-md" aria-hidden="true"></i>Clínicos</a>
        <a href="dashboard_admin.php?operacao=alertas" class="active"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i>Alertas</a>
        <a href="logout.php" style="margin-top:15%;"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
</div>

</html>